
public class Living extends Creature{

	private String name;
	
	@Override
	public void setName(String newName) {
		name = newName;
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public void setWeight(double newWeight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getWeight() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setHeight(double newheight) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getHeight() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setFavFood(String newFood) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getFavFood() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSpeed(double newSpeed) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double getSpeed() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setSound(String newSound) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getSound() {
		// TODO Auto-generated method stub
		return null;
	}
}
